<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="block" tilewidth="32" tileheight="22" tilecount="2" columns="2">
 <image source="block.png" width="64" height="22"/>
 <tile id="0">
  <properties>
   <property name="Collidable" value="True"/>
  </properties>
 </tile>
</tileset>
