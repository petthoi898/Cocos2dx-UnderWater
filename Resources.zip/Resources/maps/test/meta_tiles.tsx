<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="meta_tiles" tilewidth="32" tileheight="32" spacing="1" margin="1" tilecount="2" columns="2">
 <image source="meta_tiles.png" width="67" height="34"/>
 <tile id="0">
  <properties>
   <property name="Collidable" value="True"/>
  </properties>
 </tile>
</tileset>
