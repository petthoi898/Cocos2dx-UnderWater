<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="nature" tilewidth="32" tileheight="32" tilecount="180" columns="20">
 <image source="RPG Nature Tileset.png" trans="000000" width="641" height="288"/>
</tileset>
