<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="meta_tiles" tilewidth="16" tileheight="16" spacing="1" margin="1" tilecount="6" columns="3">
 <image source="meta_tiles.png" width="67" height="34"/>
 <tile id="0">
  <properties>
   <property name="Collidable" value="True"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="Collidable" value="True"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="Collidable" value="True"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="Collidable" value="True"/>
  </properties>
 </tile>
</tileset>
