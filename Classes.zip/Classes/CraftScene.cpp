﻿#include "CraftScene.h"
#include "cocos2d.h"
#include "ui/UIScrollView.h"
#include "ui/UIButton.h"
#include <list>
USING_NS_CC;
using namespace ui;


vector<pair<Item*, int>> CraftScene::currentItem;
Scene* CraftScene::createScene(RenderTexture* sqr, vector<pair<Item*, int>> cur) {

	currentItem = cur;
	auto scene = Scene::create();
	auto layer = CraftScene::create();
	scene->addChild(layer, 1);
	auto visibleSize = Director::getInstance()->getVisibleSize();
	auto back_sqr = Sprite::createWithTexture(sqr->getSprite()->getTexture());
	back_sqr->setPosition(Point(visibleSize.width / 2, visibleSize.height / 2));
	back_sqr->setFlippedY(true);
	back_sqr->setColor(Color3B::GRAY);
	scene->addChild(back_sqr);
	return scene;
}


bool CraftScene::init() {
	auto visibleSize = Director::getInstance()->getVisibleSize();
	auto origin = Director::getInstance()->getVisibleOrigin();
	getItemNeeded();
	getItemNeeded2();
	getItemNeeded3();
	auto back = Sprite::create("Crafting.png");
	back->setPosition(visibleSize.width / 2, visibleSize.height / 2);
	back->setScale(2.3);
	addChild(back);

	//add button items
	auto btn_items1 = Button::create("items/49.png");
	btn_items1->setPosition(Vec2(visibleSize.width / 3, visibleSize.height / 1.5));
	btn_items1->setScale(1.5);

	btn_items1->addTouchEventListener([&](Ref* sender, Widget::TouchEventType type)
	{
		switch (type)
		{
		case cocos2d::ui::Widget::TouchEventType::BEGAN:
			break;
		case cocos2d::ui::Widget::TouchEventType::MOVED:
			break;
		case cocos2d::ui::Widget::TouchEventType::ENDED:
			addDetail();
			break;
		case cocos2d::ui::Widget::TouchEventType::CANCELED:
			break;
		default:
			break;
		}
	});
	this->addChild(btn_items1, 1);

	items1 = Sprite::create("items/49.png");
	items1->setPosition(Vec2(visibleSize.width / 3, visibleSize.height / 1.5));
	items1->setVisible(false);
	addChild(items1, 2);

	auto btn_items2 = Button::create("items/106.png");
	btn_items2->setPosition(Vec2(visibleSize.width / 3, visibleSize.height / 1.75));
	btn_items2->setScale(1.5);

	btn_items2->addTouchEventListener([&](Ref* sender, Widget::TouchEventType type)
	{
		switch (type)
		{
		case cocos2d::ui::Widget::TouchEventType::BEGAN:
			break;
		case cocos2d::ui::Widget::TouchEventType::MOVED:
			break;
		case cocos2d::ui::Widget::TouchEventType::ENDED:
			addDetail1();
			break;
		case cocos2d::ui::Widget::TouchEventType::CANCELED:
			break;
		default:
			break;
		}
	});
	items2 = Sprite::create("items/106.png");
	items2->setPosition(Vec2(visibleSize.width / 3, visibleSize.height / 1.75));
	//items2->setVisible(false);
	//
	this->addChild(btn_items2, 1);
	addChild(items2);


	//craftButton->setPosition(visibleSize.width / 2 + 100, visibleSize.height / 2);
	auto exit = MenuItemImage::create("CloseNormal.png", "CloseSelected.png", CC_CALLBACK_1(CraftScene::exit, this));
	exit->setPosition(exit->getPositionX() + 250, exit->getPositionY() + 200);
	exit->setScale(0.7);
	auto menu = Menu::create(exit, NULL);
	menu->setPosition(visibleSize.width / 2 + 100, visibleSize.height / 2);
	addChild(menu);


	this->scheduleUpdate();

	return true;
}
void CraftScene::getItemNeeded() {
	auto name = "items/r (1).png";
	auto name2 = "items/r (2).png";
	auto item = new Item(0, name, name, name, 1, name, Sprite::create(name));
	auto item2 = new Item(0, name2, name2, name2, 1, name2, Sprite::create(name2));
	pair<Item*, int> a;
	pair<Item*, int> b;
	a.first = item;
	b.first = item2;
	a.second = 2;
	b.second = 1;
	itemNeeded.push_back(a);
	itemNeeded.push_back(b);
}
void CraftScene::getItemNeeded2() {
	auto name = "items/r (4).png";
	auto name2 = "items/r (5).png";
	auto name3 = "items/r (6).png";
	auto item = new Item(0, name, name, name, 1, name, Sprite::create(name));
	auto item2 = new Item(0, name2, name2, name2, 1, name2, Sprite::create(name2));
	auto item3 = new Item(0, name3, name3, name3, 1, name3, Sprite::create(name3));
	pair<Item*, int> a;
	pair<Item*, int> b;
	pair<Item*, int> c;
	a.first = item;
	b.first = item2;
	c.first = item3;
	a.second = 2;
	b.second = 1;
	c.second = 1;

	itemNeeded2.push_back(a);
	itemNeeded2.push_back(b);
	itemNeeded2.push_back(c);
}
void CraftScene::getItemNeeded3() {
	auto name = "items/r (3).png";
	auto name2 = "items/r (4).png";
	auto item = new Item(0, name, name, name, 1, name, Sprite::create(name));
	auto item2 = new Item(0, name2, name2, name2, 1, name2, Sprite::create(name2));
	pair<Item*, int> a;
	pair<Item*, int> b;
	a.first = item;
	b.first = item2;
	a.second = 2;
	b.second = 1;
	itemNeeded.push_back(a);
	itemNeeded.push_back(b);
}
void CraftScene::addDetail()
{
	auto visibleSize = Director::getInstance()->getVisibleSize();
	auto detail = Sprite::create("detail/Sword.png");
	crafting = false;
	detail->setPosition(visibleSize.width / 1.69, visibleSize.height / 2.2);
	detail->setScale(1.87);
	addChild(detail, 1);
	//add btn_craft
	auto btn_Craft = Button::create("craft.png", "craft1.png");
	btn_Craft->setPosition(Vec2(visibleSize.width / 1.53, visibleSize.height / 5.2));
	btn_Craft->setScale(0.5);
	btn_Craft->addTouchEventListener([&](Ref* sender, Widget::TouchEventType type)
	{
		switch (type)
		{
		case cocos2d::ui::Widget::TouchEventType::BEGAN:
			CCLOG("Touch");
			crafting = true;
			break;
		case cocos2d::ui::Widget::TouchEventType::MOVED:
			break;
		case cocos2d::ui::Widget::TouchEventType::ENDED:
			//crafting = false;
			break;
		case cocos2d::ui::Widget::TouchEventType::CANCELED:
			break;
		default:
			break;
		}
	});
	this->addChild(btn_Craft, 3);
}
void CraftScene::addDetail1()
{
	auto visibleSize = Director::getInstance()->getVisibleSize();
	auto detail = Sprite::create("detail/Potion.png");
	crafting1 = false;
	detail->setPosition(visibleSize.width / 1.69, visibleSize.height / 2.2);
	detail->setScale(1.87);
	addChild(detail, 1);

	//add btn_craft
	auto btn_Craft = Button::create("craft.png", "craft1.png");
	btn_Craft->setPosition(Vec2(visibleSize.width / 1.53, visibleSize.height / 5.2));
	btn_Craft->setScale(0.5);
	btn_Craft->addTouchEventListener([&](Ref* sender, Widget::TouchEventType type)
	{
		switch (type)
		{
		case cocos2d::ui::Widget::TouchEventType::BEGAN:
			CCLOG("Touch");
			crafting1 = true;
			break;
		case cocos2d::ui::Widget::TouchEventType::MOVED:
			break;
		case cocos2d::ui::Widget::TouchEventType::ENDED:

			break;
		case cocos2d::ui::Widget::TouchEventType::CANCELED:
			break;
		default:
			break;
		}
	});
	this->addChild(btn_Craft, 3);
}

void CraftScene::exit(Ref* sender) {
	Director::getInstance()->popScene();
	Director::getInstance()->resume();
}

int CraftScene::checkItemInCurrentItem(pair<Item*, int> item) {
	int i = 0;
	for (auto it : currentItem) {
		if (it.first->getItemName() == item.first->getItemName() && it.second >= item.second) return i;
		i++;
	}
	return -1;
}

void CraftScene::update(float dt) {
	auto visibleSize = Director::getInstance()->getVisibleSize();
	bool canCraft = true;
	if (crafting) {

		for (auto item : itemNeeded) {
			int check = checkItemInCurrentItem(item);
			if (-1 == check)
			{
				canCraft = false;
				break;
			}
		}
		if (canCraft) {
			auto notice = Sprite::create("craft done.png");
			notice->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
			addChild(notice, 5);
			auto name = "items/w.png";
			auto item = new Item(0, name, name, name, 1, "weapon", Sprite::create(name));
			pair<Item*, int> a;
			a.first = item;
			a.second = 1;
			for (auto item : itemNeeded) {
				auto it = currentItem.begin();
				for (int i = 0; i < currentItem.size(); i++) {
					if (item.first->getItemName() == (*it).first->getItemName()) {
						if ((*it).second == item.second) {
							// 
							
							removeChild((*it).first);
							currentItem.erase(it, it + 1);
							break;

						}
						else {
							currentItem.at(i).second -= item.second;
							break;
						}
					}
					it++;

				}
			}
			currentItem.push_back(a);
			//addChild(item->getSprite(), 5);

		}
		else {
			auto notice = Sprite::create("craft failed.png");
			notice->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
			addChild(notice, 5);
		}

		crafting = false;
	}
	if (crafting1) {

		for (auto item : itemNeeded2) {
			int check = checkItemInCurrentItem(item);
			if (-1 == check)
			{
				canCraft = false;
				break;
			}
		}
		if (canCraft) {
			auto notice = Sprite::create("craft done.png");
			notice->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
			addChild(notice, 5);
			auto name = "items/106.png";
			auto item = new Item(0, name, name, name, 1, "heal", Sprite::create(name));
			pair<Item*, int> a;
			a.first = item;
			a.second = 1;
			for (auto item : itemNeeded2) {
				auto it = currentItem.begin();
				for (int i = 0; i < currentItem.size(); i++) {
					if (item.first->getItemName() == (*it).first->getItemName()) {
						if ((*it).second == item.second) {
							currentItem.erase(it, it + 1);
							break;

						}
						else {
							currentItem.at(i).second -= item.second;
							break;
						}
					}
					it++;

				}
			}
			currentItem.push_back(a);
			//addChild(item->getSprite(), 5);
			crafting1 = false;
		}
		else {
			auto notice = Sprite::create("craft failed.png");
			notice->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
			addChild(notice, 5);
		}

		crafting = false;
	}
}
