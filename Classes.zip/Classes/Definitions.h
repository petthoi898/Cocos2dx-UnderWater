#ifndef __DEFINITIONS_H__  
#define __DEFINITIONS_H__  

#define RUN_SPEED 5
#define MEDUSADAMAGE 8
#define HERODAMAGE 15
#define DRAGONDAMAGE 13
#define DEMONDAMAGE 15

#define ITEMHIDE 150
#define TRANSITION_TIME 0.5f
#endif // __DEFINITIONS_H__  