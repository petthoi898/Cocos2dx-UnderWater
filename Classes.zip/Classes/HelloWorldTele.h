
#ifndef __HELLO_WORLD_TELE_H__
#define __HELLO_WORLD_TELE_H__
#include "Enemy.h"
#include "cocos2d.h"
#include "HRocker.h"
#include "Hero.h"
#include "ProgressView.h"
#include "Item.h"
#include "Information.h"
using namespace cocos2d;

class HelloWorldTele : public cocos2d::Scene
{
public:
	static cocos2d::Scene* createScene(Information* infor);
	virtual bool init();
	// In the public section
	void setViewPointCenter(Point position);
	void combat(Enemy* enemy);
	virtual void update(float delta);
	bool isRectCollision(Rect rect1, Rect rect2);
	void usingItem(int scaleAt);
	int checkExistItem(Item* item);
	void setCraftedItem();
	void setPlayerPosition(Point position);
	Point tileCoordForPosition(Point position);
	void initHRocker();
	CREATE_FUNC(HelloWorldTele);

private:

	TMXTiledMap *_tileMap;
	TMXLayer *_background;
	TMXLayer *_blockage;
	HRocker*  rocker;
	Hero*    hero;
	vector<Enemy*> enemy;
	ProgressView* view;
	ProgressView* view1;
	ProgressView* view2;
	Sprite* aroundCharacter;
	Sprite* character;
	vector<pair<Item*, int>> listItem;
	vector<pair<Item*, int>> collectedItem;
	vector<pair<Item*, int>> craftedItem;
	Sprite* tele;
	Node* cameraView;
	static Information* infor;
};

#endif // __HELLO_WORLD_TELE_H__
