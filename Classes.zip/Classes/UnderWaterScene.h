
#ifndef __UNDER_WATER_SCENE_H__
#define __UNDER_WATER_SCENE_H__
#include "Enemy.h"
#include "cocos2d.h"
#include "HRocker.h"
#include "Hero.h"
#include "ProgressView.h"
#include "Item.h"
#include "Information.h"
using namespace cocos2d;

class UnderWater : public cocos2d::Scene
{
public:
	static cocos2d::Scene* createScene(Information* infor);
	virtual bool init();
	// In the public section
	void setViewPointCenter(Point position);
	void combat(Enemy* enemy);
	virtual void update(float delta);
	float time;
	bool isRectCollision(Rect rect1, Rect rect2);
	void usingItem(int& scaleAt);
	void setPlayerPosition(Point position);
	Point tileCoordForPosition(Point position);
	void setCraftedItem();
	CREATE_FUNC(UnderWater);

private:
	int checkExistItem(Item * item);

	TMXTiledMap *_tileMap;
	TMXLayer *_background;
	TMXLayer *_blockage;
	HRocker*  rocker;
	Hero*    hero;
	vector<Enemy*> enemy;
	ProgressView* view;
	ProgressView* view1;
	ProgressView* view2;
	Sprite* aroundCharacter;
	Sprite* character;
	vector<pair<Item*, int>> listItem;
	vector<pair<Item*, int>> collectedItem;
	vector<pair<Item*, int>> craftedItem;

	Sprite* tele;
	Node* cameraView;
	static Information* infor;
};

#endif // __UNDER_WATER_SCENE_H__
