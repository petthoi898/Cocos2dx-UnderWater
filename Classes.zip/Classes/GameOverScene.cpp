﻿#include "cocos2d.h"
#include "GameOverScene.h"
#include "MainMenuScene.h"
#include "HelloWorldScene.h"
USING_NS_CC;


Scene* GameOverScene::createScene() {
	auto scene = Scene::create();
	auto layer = GameOverScene::create();
	scene->addChild(layer);
	return scene;
}
bool GameOverScene::init() {
	/*auto visibleSize = Director::getInstance()->getVisibleSize();
	auto retry = MenuItemImage::create("Retry Button Clicked.png", "Retry Button Clicked.png", CC_CALLBACK_1(GameOverScene::goToNewGame, this));
	retry->setPosition(Vec2(visibleSize.width / 8, visibleSize.height / 4));
	auto goToMenu = MenuItemImage::create("Play Button Clicked.png", "Play Button Clicked.png", CC_CALLBACK_1(GameOverScene::goToMainMenu, this));
	goToMenu->setPosition(Vec2(visibleSize.width * 3 / 8, visibleSize.height / 4));
	auto menu = Menu::create(retry, goToMenu, NULL);
	addChild(menu, 1000);*/

	auto visibleSize = Director::getInstance()->getVisibleSize();


	auto background = Sprite::create("sea_background/sea_background.png");
	addChild(background, -4);
	auto farground = Sprite::create("sea_background/farground.png");
	addChild(farground, -3);
	auto midground = Sprite::create("sea_background/mid_background.png");
	addChild(midground, -2);
	auto foreground = Sprite::create("sea_background/foreground.png");
	addChild(foreground, -1);
	background->setPosition(visibleSize.width / 2, visibleSize.height / 2);
	farground->setPosition(visibleSize.width / 2, visibleSize.height / 2);
	midground->setPosition(visibleSize.width / 2, visibleSize.height / 2);
	foreground->setPosition(visibleSize.width / 2, visibleSize.height / 2);

	schedule(CC_SCHEDULE_SELECTOR(MainMenuScene::spawnBubble), 1, CC_REPEAT_FOREVER, 0.1f);


	auto buttonControls = MenuItemImage::create("gamecontrol/Play Button.png", "gamecontrol/Play Button.png",
		CC_CALLBACK_1(GameOverScene::goToNewGame, this));
	buttonControls->setScale(0.5f);
	buttonControls->setPosition(0, 10);
	auto buttonExit = MenuItemImage::create("gamecontrol/Quit Button.png", "gamecontrol/Quit Button.png",
		CC_CALLBACK_1(GameOverScene::goToMainMenu, this));
	buttonExit->setScale(0.5f);
	buttonExit->setPosition(Point(buttonControls->getPositionX(), buttonControls->getPositionY() - 100));
	auto menu = Menu::create(buttonControls, buttonExit, NULL);
	addChild(menu);
	return true;
}
void GameOverScene::goToNewGame(Ref* sender) {
	auto scene = HelloWorld::createScene();
	Director::getInstance()->replaceScene(TransitionFade::create(1, scene));
}
void GameOverScene::goToMainMenu(Ref* sender) {

	Director::getInstance()->end();
}