#ifndef __CRAFT_SCENE_H__
#define __CRAFT_SCENE_H__

#include "cocos2d.h"
#include "Item.h"
#include <vector>
#include "ui/UIButton.h"
USING_NS_CC;
using namespace ui;

class CraftScene : Scene {

public:
	static Scene* createScene(RenderTexture* sqr, vector<pair<Item*, int>> cur);
	virtual bool init();
	void exit(Ref* sender);
	void setCurrentItem(vector<pair<Item*, int>> listItem) { currentItem = listItem; };
	static vector<pair<Item*, int>> getCurrentItem() { return currentItem; }
	virtual void update(float delta);
	CREATE_FUNC(CraftScene);
	void getItemNeeded();
	void getItemNeeded2();
	void getItemNeeded3();
	void addDetail();
	void addDetail1();
	void addDetail3();
private:
	int checkItemInCurrentItem(pair<Item*, int> item);
	bool isCanCraft;
	bool crafting;
	bool crafting1;
	Sprite* items1;
	Sprite* items2;
	Sprite* items3;
	vector<bool> vectorCraft;
	vector<Button*> buttonCraft;
	static vector<pair<Item*, int>> currentItem;
	vector<pair<Item*, int>> itemNeeded;
	vector<pair<Item*, int>> itemNeeded2;
	vector<pair<Item*, int>> itemNeeded3;

};

#endif // __CRAFT_SCENE_H__
