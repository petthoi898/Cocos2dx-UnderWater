
#include "UnderWaterScene.h"
#include "HelloWorldTele.h"
#include "GameOverScene.h"
#include "CraftScene.h"
USING_NS_CC;
Information* UnderWater::infor = NULL;
Scene* UnderWater::createScene(Information* _infor)
{
	infor = _infor;
	return UnderWater::create();
}

// on "init" you need to initialize your instance
bool UnderWater::init()
{
	//////////////////////////////
	// 1. super init first
	if (!Scene::init())
	{
		return false;
	}

	auto visibleSize = Director::getInstance()->getVisibleSize();
	Vec2 origin = Director::getInstance()->getVisibleOrigin();


	for (auto item : infor->item) {
		auto it = new  Item(item.first->getItemID(), item.first->getItemName(), item.first->getItemDescription(), item.first->getItemImg(), item.first->getItemUsable(), item.first->getItemType(), Sprite::create(item.first->getItemName()));
		pair<Item*, int> a;
		a.first = it;
		a.second = 1;
		collectedItem.push_back(a);
		addChild(it->getSprite(), 2);
	}
	_tileMap = TMXTiledMap::create("maps/under_water.tmx");
	_background = _tileMap->getLayer("Background");
	//_blockage = _tileMap->getLayer("Blockage");
	//_blockage->setVisible(false);
	addChild(_tileMap, -1);
	TMXObjectGroup *objects = _tileMap->getObjectGroup("Object");
	//CCASSERT(NULL != objects, "'Object-Player' object group not found");
	auto playerShowUpPoint = objects->getObject("spawnpoint");
	CCASSERT(!playerShowUpPoint.empty(), "PlayerShowUpPoint object not found");

	int x = playerShowUpPoint["x"].asInt();
	int y = playerShowUpPoint["y"].asInt();


	auto telePort = objects->getObject("teleport");

	int telePortX = telePort["x"].asInt();
	int telePortY = telePort["y"].asInt();

	tele = Sprite::create("teleport.png");
	tele->setPosition(telePortX, telePortY);
	tele->setScale(0.5f);
	addChild(tele, 1);

	//init list item



	for (int i = 1; i <= 6; i++) {
		char imageName[100] = { 0 };
		sprintf(imageName, "items/r (%d).png", i);
		auto sprite = Sprite::create(imageName);
		auto item = new Item(i, imageName, imageName, imageName, 0, imageName, sprite);
		addChild(item->getSprite(), 5);
		item->getSprite()->setVisible(false);
		pair<Item*, int> a;
		a.first = item;
		a.second = 1;
		listItem.push_back(a);
	}

	// spawn enemy
	auto groupEnemy = _tileMap->getObjectGroup("Monster");
	CCASSERT(NULL != groupEnemy, "'Enemy' object group not found");

	auto monster = groupEnemy->getObjects();
	auto iteratorMonster = monster.begin();
	for (; iteratorMonster != monster.end(); iteratorMonster++) {
		ValueMap& dict = (*iteratorMonster).asValueMap();
		if ("dragon" == dict["name"].asString()) {
			float x = dict["x"].asFloat();
			float y = dict["y"].asFloat();
			Enemy* enemySprite = new Enemy();
			enemySprite->initSpriteEnemyDragon(Point(x, y));
			int spriteNumber = CCRANDOM_0_1()*100;
			spriteNumber %= listItem.size();
			auto name = listItem.at(spriteNumber).first;
			auto item = new Item(name->getItemID(), name->getItemName(), name->getItemName(), name->getItemName(), 1, name->getItemType(), Sprite::create(name->getItemName()));
			addChild(item->getSprite(), 5);
			enemySprite->setItemEnemy(item);
			enemySprite->itemEnemy->setSprite(Point(x, y));
			enemySprite->itemEnemy->getSprite()->setVisible(false);
			enemy.push_back(enemySprite);
			enemySprite->setViewEnemy(Point(x, y));
			enemySprite->type = "dragon";
			addChild(enemySprite, -1);
		}
		else if ("medusa" == dict["name"].asString()) {
			float x = dict["x"].asFloat();
			float y = dict["y"].asFloat();
			Enemy* enemySprite = new Enemy();
			enemySprite->initSpriteEnemyMedusa(Point(x, y));
			int spriteNumber = CCRANDOM_0_1() * 100;
			spriteNumber %= listItem.size();
			auto name = listItem.at(spriteNumber).first;
			auto item = new Item(name->getItemID(), name->getItemName(), name->getItemName(), name->getItemName(), 1, name->getItemType(), Sprite::create(name->getItemName()));
			addChild(item->getSprite(), 5);
			enemySprite->setItemEnemy(item);
			enemySprite->itemEnemy->setSprite(Point(x, y));
			enemySprite->itemEnemy->getSprite()->setVisible(false);
			enemy.push_back(enemySprite);
			enemySprite->setViewEnemy(Point(x, y));
			enemySprite->type = "medusa";
			addChild(enemySprite, -1);
		}
		else if ("medon" == dict["name"].asString()) {
			float x = dict["x"].asFloat();
			float y = dict["y"].asFloat();
			Enemy* enemySprite = new Enemy();
			enemySprite->initSpriteEnemyDemon(Point(x, y));
			int spriteNumber = CCRANDOM_0_1() * 100;
			spriteNumber %= listItem.size();

			auto name = listItem.at(spriteNumber).first;
			auto item = new Item(name->getItemID(), name->getItemName(), name->getItemName(), name->getItemName(), 1, name->getItemType(), Sprite::create(name->getItemName()));
			addChild(item->getSprite(), 5);
			enemySprite->setItemEnemy(item);
			enemySprite->itemEnemy->setSprite(Point(x, y));
			enemySprite->itemEnemy->getSprite()->setVisible(false);
			enemy.push_back(enemySprite);
			enemySprite->setViewEnemy(Point(x, y));
			enemySprite->type = "demon";
			addChild(enemySprite, -1);
		}
	}

	hero = Hero::create();
	hero->InitHeroSprite("character/hero_idle1.png");
	hero->setPosition(x, y);
	hero->setScale(2.2f);
	hero->setHeroDamage(infor->hero->getHeroDamage());
	this->addChild(hero, 1);

	cameraView = Node::create();
	cameraView->setContentSize(visibleSize);
	this->addChild(cameraView);
	this->runAction(Follow::create(cameraView));
	setViewPointCenter(hero->getPosition());

	rocker = HRocker::createHRocker("joystick_center.png", "joystick_bg.png", Point(100, 100), collectedItem);// where the first picture is a rocker button, the second as the background  
	rocker->setPosition(-cameraView->getContentSize().width / 2, -cameraView->getContentSize().height / 2);
	rocker->setTag(50);
	rocker->startRocker(true);

	cameraView->addChild(rocker, 2);

	//set time underwater
	time = 60.0f;
	scheduleUpdate();

	auto characterInfo = Node::create();
	characterInfo->setPosition(Point(-380, 195));
	cameraView->addChild(characterInfo);

	// hp bar
	view = new ProgressView();
	view->setScale(0.26f);
	view->setBackgroundTexture("character/blankBar.png");
	view->setForegroundTexture("character/hpBar.png");
	view->setPosition(Point(13, 27));
	//view->setPosition(aroundCharacter->getPosition());
	view->setTotalProgress(infor->view->getTotalProgress());
	view->setCurrentProgress(infor->view->getCurrentProgress());

	// amor bar
	view1 = new ProgressView();
	view1->setScale(0.26f);
	view1->setBackgroundTexture("character/blankBar.png");
	view1->setForegroundTexture("character/armorBar.png");
	view1->setPosition(Point(13, 3.5));
	view1->setTotalProgress(100);
	view1->setCurrentProgress(100);

	//oxygen bar
	view2 = new ProgressView();
	view2->setScale(0.26f);
	view2->setBackgroundTexture("character/blankBar.png");
	view2->setForegroundTexture("character/mpBar.png");
	view2->setPosition(Point(13, -18));
	view2->setTotalProgress(time);
	view2->setCurrentProgress(time);

	aroundCharacter = Sprite::create("character/statusBox.png");
	aroundCharacter->setScale(0.35f);
	/*character = Sprite::create("character/touxiang.png");
	character->setPosition(Point(-120, 0));*/

	//characterInfo->addChild(character, 2);
	characterInfo->addChild(aroundCharacter, 2);
	characterInfo->addChild(view, 2);
	characterInfo->addChild(view1, 2);
	characterInfo->addChild(view2, 2);

	this->scheduleUpdate();


	return true;
}

void UnderWater::setViewPointCenter(Point position) {
	auto winSize = Director::getInstance()->getVisibleSize();

	int x = MAX(position.x, winSize.width / 2);
	int y = MAX(position.y, winSize.height / 2);
	x = MIN(x, (_tileMap->getMapSize().width * this->_tileMap->getTileSize().width) - winSize.width / 2);
	y = MIN(y, (_tileMap->getMapSize().height * _tileMap->getTileSize().height) - winSize.height / 2);
	auto actualPosition = Point(x, y);

	auto centerOfView = Point(winSize.width / 2, winSize.height / 2);
	auto viewPoint = centerOfView - actualPosition;
	if (viewPoint.x > winSize.width / 2) {
		cameraView->setPosition(viewPoint);
	}
	else cameraView->setPosition(actualPosition);
}

void UnderWater::update(float delta)
{
	setCraftedItem();
	//time underwater
	time -= delta;
	view2->setCurrentProgress(time);
	if (view2->getCurrentProgress() <= 0) {
		auto scene = GameOverScene::createScene();
		Director::getInstance()->replaceScene(TransitionFade::create(1, scene));
	}
	setViewPointCenter(hero->getPosition());
	rocker->setQuickItem(collectedItem);
	
	auto heroX = hero->getPositionX();
	auto heroY = hero->getPositionY();
	usingItem(rocker->scaleAt);
	if (rocker->isInAttack) {
		hero->getAttackAmination();
		for (int i = 0; i < enemy.size(); i++) {
			if (!enemy.at(i)->isDead) {
				auto position = enemy.at(i)->enemySprite->getPositionY();
				if (std::abs(hero->getPositionY() - position) < 30)
				{
					if (isRectCollision(Rect(heroX, heroY, 32, 32),
						Rect(enemy.at(i)->enemySprite->getPositionX(), enemy.at(i)->enemySprite->getPositionY(), 256, 256)))
					{
						combat(enemy.at(i));
						enemy.at(i)->isHurt = true;
					}
				}
			}
			else if (!enemy.at(i)->isCollected) {
				auto itemX = enemy.at(i)->itemEnemy->getSprite()->getPositionX();
				auto itemY = enemy.at(i)->itemEnemy->getSprite()->getPositionY();
				if (isRectCollision(Rect(heroX, heroY, 32, 32), Rect(itemX, itemY, 32, 32))) {
					CCLOG("Collision item");
					auto moveDown = MoveTo::create(1, rocker->getBagPosition());
					auto visibleItem = CallFunc::create([=]() {
						enemy.at(i)->itemEnemy->getSprite()->setVisible(false);
					});
					auto seq = Sequence::create(moveDown, visibleItem, NULL);
					enemy.at(i)->itemEnemy->getSprite()->runAction(seq);
					enemy.at(i)->isCollected = true;

					int check = checkExistItem(enemy.at(i)->itemEnemy);
					if (-1 == check) {
						pair<Item*, int> a;
						a.first = enemy.at(i)->itemEnemy;
						a.second = 1;
						collectedItem.push_back(a);
					}
					else {
						collectedItem.at(check).second++;
					}
					rocker->setQuickItem(collectedItem);
					//rocker->setQuickItem(listItem);
				}
			}
			rocker->isInAttack = false;
		}

	}

	if (isRectCollision(Rect(heroX, heroY, 32, 32), Rect(tele->getPositionX(), tele->getPositionY(), tele->getContentSize().width, tele->getContentSize().height))) {
		auto infor = new Information(hero, view, collectedItem);
		auto scene = HelloWorldTele::createScene(infor);
		Director::getInstance()->replaceScene(TransitionFade::create(0.5f, scene));
	}
	if (rocker->isCraft) {
		auto a = CraftScene::getCurrentItem();
		if (a.size() > 0) {
			for (auto item : craftedItem) {
				if (a.at(a.size() - 1).first->getItemName() == item.first->getItemName()) {
					a.pop_back();
					a.push_back(item);
					collectedItem = a;

					rocker->setQuickItem(collectedItem);
					rocker->isCraft = false;
				}
			}
		}

	}
	//load item
	int sizeNew = collectedItem.size();
	rocker->loadQuickItem(cameraView->getPosition(), cameraView->getContentSize());
	// run 
	switch (rocker->rocketDirection)
	{
	case 1:
		hero->SetAnimation("character/run_animation.plist", "character/run_animation.png", "run", 6, rocker->rocketRun);// "run_" is a collection of images in each image run_animation.png common name part  
		hero->setPosition(Point(hero->getPosition().x + 5, hero->getPosition().y)); // right away  
		break;
	case  2:
		hero->SetAnimation("character/run_animation.plist", "character/run_animation.png", "run", 6, rocker->rocketRun);// "run_" is a collection of images in each image run_animation.png common name part  
		hero->setPosition(Point(hero->getPosition().x, hero->getPosition().y + 5));   // go up  
		break;
	case 3:
		hero->SetAnimation("character/run_animation.plist", "character/run_animation.png", "run", 6, rocker->rocketRun);// "run_" is a collection of images in each image run_animation.png common name part  
		hero->setPosition(Point(hero->getPosition().x - 5, hero->getPosition().y));   //turn left  
		break;
	case 4:
		hero->SetAnimation("character/run_animation.plist", "character/run_animation.png", "run", 6, rocker->rocketRun);// "run_" is a collection of images in each image run_animation.png common name part  
		hero->setPosition(Point(hero->getPosition().x, hero->getPosition().y - 5));   // go down  
		break;
	default:
		hero->StopAnimation();
		break;

	}
}
bool UnderWater::isRectCollision(Rect rect1, Rect rect2) {

	float x1 = rect1.origin.x;
	float y1 = rect1.origin.y;
	float w1 = rect1.size.width;
	float h1 = rect1.size.height;
	float x2 = rect2.origin.x;
	float y2 = rect2.origin.y;
	float w2 = rect2.size.width;
	float h2 = rect2.size.height;

	if (x1 + w1 * 0.5 < x2 - w2 * 0.5)
		return false;
	else if (x1 - w1 * 0.5 > x2 + w2 * 0.5)
		return false;
	else if (y1 + h1 * 0.5 < y2 - h2 * 0.5)
		return false;
	else if (y1 - h1 * 0.5 > y2 + h2 * 0.5)
		return false;

	return true;
}
void UnderWater::combat(Enemy* ene) {
	auto position = ene->enemySprite->getPositionY();
	auto heroX = hero->getPositionX();
	auto heroY = hero->getPositionY();
	if (std::abs(hero->getPositionY() - position) < 30)
	{
		if (isRectCollision(Rect(heroX, heroY, 32, 32),
			Rect(ene->enemySprite->getPositionX(), ene->enemySprite->getPositionY(), 256, 256)))
		{
			if ("dragon" == ene->type) {
				ene->enemyHurt();
				if (heroX < ene->enemyPosition.x) ene->enemySprite->setFlippedX(true);
				else ene->enemySprite->setFlippedX(false);
				ene->enemyFollow(Point(heroX, heroY));
				ene->enemyAttack();
				view->setCurrentProgress(view->getCurrentProgress() - ene->getDragonDamage());
				ene->viewEnemy->setCurrentProgress(ene->viewEnemy->getCurrentProgress() - hero->getHeroDamage());
				ene->isDead = ene->viewEnemy->getCurrentProgress() > 0 ? 0 : 1;
				auto a = view->getCurrentProgress();
				if (view->getCurrentProgress() <= 0) {
					auto scene = GameOverScene::createScene();
					Director::getInstance()->replaceScene(TransitionFade::create(1, scene));
				}
				if (ene->isDead) {
					ene->enemyDead();
					ene->removeEnemyDead();
					if (!ene->itemDroped) {
						ene->itemEnemy->getSprite()->setVisible(true);
						auto setpos = ene->enemyPosition;
						ene->itemEnemy->setSprite(setpos);
						auto pos = ene->itemEnemy->getSprite()->getPosition();
						auto moveUp = MoveTo::create(1, pos + Point(0, 30));
						auto moveDown = MoveTo::create(0.5f, pos);
						auto seq = Sequence::create(moveUp, moveDown, NULL);
						ene->itemEnemy->getSprite()->runAction(seq);
						ene->itemDroped = true;
					}
					if (!ene->isCollected) {
						auto itemX = ene->itemEnemy->getSprite()->getPositionX();
						auto itemY = ene->itemEnemy->getSprite()->getPositionY();
						if (isRectCollision(Rect(heroX, heroY, 32, 32), Rect(itemX, itemY, 32, 32))) {
							CCLOG("Collision item");
							auto moveDown = MoveTo::create(1, rocker->getBagPosition());
							auto visibleItem = CallFunc::create([=]() {
								ene->itemEnemy->getSprite()->setVisible(false);
							});
							auto seq = Sequence::create(moveDown, visibleItem, NULL);
							ene->itemEnemy->getSprite()->runAction(seq);
							ene->isCollected = true;
							int check = checkExistItem(ene->itemEnemy);
							if (-1 == check) {
								pair<Item*, int> a;
								a.first = ene->itemEnemy;
								a.second = 1;
								collectedItem.push_back(a);
							}
							else {
								collectedItem.at(check).second++;
							}
							rocker->setQuickItem(collectedItem);
						}

					}
				}
			}
			else if ("medusa" == ene->type) {
				ene->enemyHurt();
				if (heroX < ene->enemyPosition.x) ene->enemySprite->setFlippedX(true);
				else ene->enemySprite->setFlippedX(false);
				ene->enemyFollow(Point(heroX, heroY));
				ene->enemyAttack();
				view->setCurrentProgress(view->getCurrentProgress() - ene->getMedusaDamage());
				ene->viewEnemy->setCurrentProgress(ene->viewEnemy->getCurrentProgress() - hero->getHeroDamage());
				ene->isDead = ene->viewEnemy->getCurrentProgress() > 0 ? 0 : 1;
				if (view->getCurrentProgress() <= 0) {
					auto scene = GameOverScene::createScene();
					Director::getInstance()->replaceScene(TransitionFade::create(1, scene));
				}
				if (ene->isDead) {
					ene->enemyDead();
					ene->removeEnemyDead();
					if (!ene->itemDroped) {
						ene->itemEnemy->getSprite()->setVisible(true);
						auto setpos = ene->enemyPosition;
						ene->itemEnemy->setSprite(setpos);
						auto pos = ene->itemEnemy->getSprite()->getPosition();
						auto moveUp = MoveTo::create(1, pos + Point(0, 30));
						auto moveDown = MoveTo::create(0.5f, pos);
						auto seq = Sequence::create(moveUp, moveDown, NULL);
						ene->itemEnemy->getSprite()->runAction(seq);
						ene->itemDroped = true;
					}
					if (!ene->isCollected) {
						auto itemX = ene->itemEnemy->getSprite()->getPositionX();
						auto itemY = ene->itemEnemy->getSprite()->getPositionY();
						if (isRectCollision(Rect(heroX, heroY, 32, 32), Rect(itemX, itemY, 32, 32))) {
							CCLOG("Collision item");
							auto moveDown = MoveTo::create(1, rocker->getBagPosition());
							auto visibleItem = CallFunc::create([=]() {
								ene->itemEnemy->getSprite()->setVisible(false);
							});
							auto seq = Sequence::create(moveDown, visibleItem, NULL);
							ene->itemEnemy->getSprite()->runAction(seq);
							ene->isCollected = true;
							int check = checkExistItem(ene->itemEnemy);
							if (-1 == check) {
								pair<Item*, int> a;
								a.first = ene->itemEnemy;
								a.second = 1;
								collectedItem.push_back(a);
							}
							else {
								collectedItem.at(check).second++;
							}
							rocker->setQuickItem(collectedItem);
						}

					}

				}
			}
			else if ("demon" == ene->type) {
				ene->enemyHurt();
				if (heroX < ene->enemyPosition.x) ene->enemySprite->setFlippedX(true);
				else ene->enemySprite->setFlippedX(false);
				ene->enemyFollow(Point(heroX, heroY));
				ene->enemyAttack();
				view->setCurrentProgress(view->getCurrentProgress() - ene->getDemonDamage());
				ene->viewEnemy->setCurrentProgress(ene->viewEnemy->getCurrentProgress() - hero->getHeroDamage());
				ene->isDead = ene->viewEnemy->getCurrentProgress() > 0 ? 0 : 1;
				if (view->getCurrentProgress() <= 0) {
					auto scene = GameOverScene::createScene();
					Director::getInstance()->replaceScene(TransitionFade::create(1, scene));
				}
				if (ene->isDead) {
					ene->enemyDead();
					ene->removeEnemyDead();
					if (!ene->itemDroped) {
						ene->itemEnemy->getSprite()->setVisible(true);
						auto setpos = ene->enemyPosition;
						ene->itemEnemy->setSprite(setpos);
						auto pos = ene->itemEnemy->getSprite()->getPosition();
						auto moveUp = MoveTo::create(1, pos + Point(0, 30));
						auto moveDown = MoveTo::create(0.5f, pos);
						auto seq = Sequence::create(moveUp, moveDown, NULL);
						ene->itemEnemy->getSprite()->runAction(seq);
						ene->itemDroped = true;
					}
					if (!ene->isCollected) {
						auto itemX = ene->itemEnemy->getSprite()->getPositionX();
						auto itemY = ene->itemEnemy->getSprite()->getPositionY();
						if (isRectCollision(Rect(heroX, heroY, 32, 32), Rect(itemX, itemY, 32, 32))) {
							CCLOG("Collision item");
							auto moveDown = MoveTo::create(1, rocker->getBagPosition());
							auto visibleItem = CallFunc::create([=]() {
								ene->itemEnemy->getSprite()->setVisible(false);
							});
							auto seq = Sequence::create(moveDown, visibleItem, NULL);
							ene->itemEnemy->getSprite()->runAction(seq);
							ene->isCollected = true;
							int check = checkExistItem(ene->itemEnemy);
							if (-1 == check) {
								pair<Item*, int> a;
								a.first = ene->itemEnemy;
								a.second = 1;
								collectedItem.push_back(a);
							}
							else {
								collectedItem.at(check).second++;
							}
							rocker->setQuickItem(collectedItem);
						}

					}
				}
			}
		}
	}
}
int UnderWater::checkExistItem(Item* it) {
	int i = 0;
	for (auto item : collectedItem) {
		if (item.first->getItemName() == it->getItemName()) {
			CCLOG("Exist Item");
			return i;
		}
		i++;
	}
	return -1;
}
void UnderWater::usingItem(int& scaleAt) {
	auto quickSlot = rocker->quickItem;
	if (scaleAt < 0 || quickSlot.size() <= 0) return;

	if ("items/w.png" == quickSlot.at(scaleAt).first->getItemName()) {
		hero->setHeroDamage(hero->getHeroDamage() + 50);
		collectedItem.at(scaleAt).first->setVisible(false);
		auto it = quickSlot.begin();
		for (int i = 0; i < scaleAt; i++) {
			it++;
		}
		scaleAt = -1;
		(*it).first->getSprite()->setVisible(false);
		(*it).first->setScale(1);
		quickSlot.erase(it);
		collectedItem = quickSlot;
		rocker->setQuickItem(collectedItem);
		return;
	}
	if ("items/106.png" == quickSlot.at(scaleAt).first->getItemName()) {
		auto a = view->getCurrentProgress();
		view->setTotalProgress(view->getTotalProgress() + 300);
		view->setCurrentProgress(a);

		auto it = quickSlot.begin();
		for (int i = 0; i < scaleAt; i++) {
			it++;
		}
		scaleAt = -1;
		(*it).first->getSprite()->setVisible(false);
		(*it).first->setScale(1);
		quickSlot.erase(it);
		collectedItem = quickSlot;
		rocker->setQuickItem(collectedItem);
		return;
	}


	if ("items/1.png" == quickSlot.at(scaleAt).first->getItemName()) {
		switch (rocker->facePos)
		{
		case 1:
			hero->setVisible(false);

			hero->setPosition(Point(hero->getPosition().x + ITEMHIDE, hero->getPosition().y)); // right away  

			hero->setVisible(true);
			break;
		case  2:
			hero->setVisible(false);

			hero->setPosition(Point(hero->getPosition().x, hero->getPosition().y + ITEMHIDE));   // go up 
			hero->setVisible(true);

			break;
		case 3:
			hero->setVisible(false);

			hero->setPosition(Point(hero->getPosition().x - ITEMHIDE, hero->getPosition().y));   //turn left  
			hero->setVisible(true);

			break;
		case 4:
			hero->setVisible(false);

			hero->setPosition(Point(hero->getPosition().x, hero->getPosition().y - ITEMHIDE));   // go down  
			hero->setVisible(true);

			break;
		default:
			break;

		}
		auto it = quickSlot.begin();
		for (int i = 0; i < scaleAt; i++) {
			it++;
		}
		scaleAt = -1;
		(*it).first->getSprite()->setVisible(false);
		quickSlot.erase(it);
		collectedItem = quickSlot;
		rocker->setQuickItem(collectedItem);
		rocker->facePos = -1;
		CCLOG("In here");
	}
	if ("items/r (3).png" == quickSlot.at(scaleAt).first->getItemName()) {
		view->setCurrentProgress(view->getCurrentProgress() + 20);
		if (quickSlot.at(scaleAt).second > 1) {
			quickSlot.at(scaleAt).second--;
			scaleAt = -1;
			return;
		}
		else {
			auto it = quickSlot.begin();
			for (int i = 0; i < scaleAt; i++) {
				it++;
			}
			scaleAt = -1;
			(*it).first->getSprite()->setVisible(false);
			(*it).first->setScale(1);
			quickSlot.erase(it);
			collectedItem = quickSlot;
			rocker->setQuickItem(collectedItem);
			return;
		}
	}

	if ("items/r (5).png" == quickSlot.at(scaleAt).first->getItemName()) {
		view1->setCurrentProgress(view->getCurrentProgress() + 30);
		if (quickSlot.at(scaleAt).second > 1) {
			quickSlot.at(scaleAt).second--;
			scaleAt = -1;
			return;
		}
		else {
			auto it = quickSlot.begin();
			for (int i = 0; i < scaleAt; i++) {
				it++;
			}
			scaleAt = -1;
			(*it).first->getSprite()->setVisible(false);
			(*it).first->setScale(1);
			quickSlot.erase(it);
			collectedItem = quickSlot;
			rocker->setQuickItem(collectedItem);
			return;
		}
	}

}
void UnderWater::setCraftedItem() {
	auto sprite = Sprite::create("items/w.png");
	auto item = new Item(0, "items/w.png", "items/w.png", "items/w.png", 0, "weapon", sprite);
	addChild(item->getSprite(), 5);
	pair<Item*, int> a;
	a.first = item;
	a.second = 1;
	item->getSprite()->setVisible(false);
	craftedItem.push_back(a);

	auto sprite1 = Sprite::create("items/106.png");
	auto item1 = new Item(0, "items/106.png", "items/106.png", "items/106.png", 0, "heal", sprite1);
	addChild(item1->getSprite(), 5);
	pair<Item*, int> a1;
	a1.first = item1;
	a1.second = 1;
	item->getSprite()->setVisible(false);
	craftedItem.push_back(a1);

	/*auto sprite2 = Sprite::create("items/106.png");
	auto item2 = new Item(0, "items/106.png", "items/106.png", "items/106.png", 0, "heal", sprite1);
	addChild(item2->getSprite(), 5);
	pair<Item*, int> a2;
	a2.first = item2;
	a2.second = 1;
	item2->getSprite()->setVisible(false);
	craftedItem.push_back(a2);*/
}
/*Point UnderWater::tileCoordForPosition(Point position)
{
	int x = position.x / _tileMap->getTileSize().width;
	int y = ((_tileMap->getMapSize().height * _tileMap->getTileSize().height) - position.y) / _tileMap->getTileSize().height;
	return Point(x, y);
}
void UnderWater::setPlayerPosition(Point position) {
	Point tileCoord = this->tileCoordForPosition(position);
	int tileGid = _blockage->getTileGIDAt(tileCoord);
	if (tileGid) {
		auto properties = _tileMap->getPropertiesForGID(tileGid).asValueMap();
		if (!properties.empty()) {
			auto collision = properties["Collidable"].asString();
			if ("True" == collision) {
				return;
			}
		}
	}
	hero->setPosition(position);
}
/*
void UnderWater::setCraftedItem() {
	auto sprite = Sprite::create("items/w.png");
	auto item = new Item(0, "items/w.png", "items/w.png", "items/w.png", 0, "weapon", sprite);
	addChild(item->getSprite(), 5);
	pair<Item*, int> a;
	a.first = item;
	a.second = 1;
	item->getSprite()->setVisible(false);
	craftedItem.push_back(a);

	auto sprite1 = Sprite::create("items/106.png");
	auto item1 = new Item(0, "items/106.png", "items/106.png", "items/106.png", 0, "heal", sprite1);
	addChild(item1->getSprite(), 5);
	pair<Item*, int> a1;
	a1.first = item1;
	a1.second = 1;
	item->getSprite()->setVisible(false);
	craftedItem.push_back(a1);

	/*auto sprite2 = Sprite::create("items/106.png");
	auto item2 = new Item(0, "items/106.png", "items/106.png", "items/106.png", 0, "heal", sprite1);
	addChild(item2->getSprite(), 5);
	pair<Item*, int> a2;
	a2.first = item2;
	a2.second = 1;
	item2->getSprite()->setVisible(false);
	craftedItem.push_back(a2);*/
